import { useState, useRef, useEffect } from 'react'

const C = {
  bg: '#000000', surface: 'rgba(28,28,30,0.95)', surfaceHigh: 'rgba(44,44,46,0.9)',
  border: 'rgba(255,255,255,0.08)', borderBright: 'rgba(255,255,255,0.14)',
  text: '#FFFFFF', textSec: 'rgba(255,255,255,0.55)', textTer: 'rgba(255,255,255,0.28)',
  blue: '#0A84FF', indigo: '#5E5CE6', purple: '#BF5AF2', pink: '#FF375F',
  orange: '#FF9F0A', green: '#30D158', teal: '#40CBE0', yellow: '#FFD60A', red: '#FF453A',
}

function Card({ children, style = {}, onClick }) {
  const [p, setP] = useState(false)
  return (
    <div onClick={onClick} onMouseDown={() => onClick && setP(true)} onMouseUp={() => setP(false)} onMouseLeave={() => setP(false)}
      style={{ background: C.surface, border: '1px solid ' + C.border, borderRadius: 20, backdropFilter: 'blur(20px)', WebkitBackdropFilter: 'blur(20px)', transform: p ? 'scale(0.97)' : 'scale(1)', transition: 'transform 0.15s cubic-bezier(.34,1.56,.64,1)', cursor: onClick ? 'pointer' : 'default', ...style }}>
      {children}
    </div>
  )
}

function ScoreRing({ score, size = 100, stroke = 9 }) {
  const r = (size - stroke) / 2, circ = 2 * Math.PI * r
  const [a, setA] = useState(0)
  useEffect(() => { const t = setTimeout(() => setA(score), 400); return () => clearTimeout(t) }, [score])
  return (
    <div style={{ position: 'relative', width: size, height: size, flexShrink: 0 }}>
      <svg width={size} height={size} style={{ transform: 'rotate(-90deg)' }}>
        <defs>
          <linearGradient id="g1" x1="0%" y1="0%" x2="100%" y2="0%">
            <stop offset="0%" stopColor="#0A84FF" /><stop offset="100%" stopColor="#BF5AF2" />
          </linearGradient>
        </defs>
        <circle cx={size/2} cy={size/2} r={r} fill="none" stroke="rgba(255,255,255,0.07)" strokeWidth={stroke} />
        <circle cx={size/2} cy={size/2} r={r} fill="none" stroke="url(#g1)" strokeWidth={stroke}
          strokeDasharray={circ} strokeDashoffset={circ - (a/100)*circ} strokeLinecap="round"
          style={{ transition: 'stroke-dashoffset 1.3s cubic-bezier(.22,.68,0,1.2)' }} />
      </svg>
      <div style={{ position: 'absolute', inset: 0, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center' }}>
        <div style={{ fontSize: size > 80 ? 24 : 15, fontWeight: 800, color: C.text, letterSpacing: -0.5 }}>{a}</div>
        <div style={{ fontSize: 9, color: C.textSec, fontWeight: 600, letterSpacing: 0.5 }}>SCORE</div>
      </div>
    </div>
  )
}

function ProgressBar({ value, color, height = 6 }) {
  const [a, setA] = useState(0)
  useEffect(() => { const t = setTimeout(() => setA(value), 300); return () => clearTimeout(t) }, [value])
  return (
    <div style={{ background: 'rgba(255,255,255,0.09)', borderRadius: 99, height, overflow: 'hidden' }}>
      <div style={{ width: a + '%', height: '100%', background: color, borderRadius: 99, transition: 'width 1.1s cubic-bezier(.22,.68,0,1.2)' }} />
    </div>
  )
}

function Pill({ children, color }) {
  return <span style={{ background: color + '22', color, fontSize: 10, fontWeight: 700, padding: '2px 8px', borderRadius: 99, border: '1px solid ' + color + '44', letterSpacing: 0.3 }}>{children}</span>
}

// ── HOME ──
function HomeScreen({ nav }) {
  const h = new Date().getHours()
  const gr = h < 12 ? 'صباح الخير' : h < 17 ? 'مساء النور' : 'مساء الخير'
  const [ready, setReady] = useState(false)
  useEffect(() => { setTimeout(() => setReady(true), 200) }, [])

  return (
    <div style={{ flex: 1, overflowY: 'auto', paddingBottom: 90 }}>
      {/* Glow */}
      <div style={{ position: 'relative', overflow: 'hidden' }}>
        <div style={{ position: 'absolute', width: 280, height: 280, borderRadius: '50%', background: C.indigo, filter: 'blur(80px)', opacity: 0.18, top: -80, right: -60, pointerEvents: 'none' }} />
        <div style={{ position: 'absolute', width: 200, height: 200, borderRadius: '50%', background: C.purple, filter: 'blur(70px)', opacity: 0.12, top: 40, left: -80, pointerEvents: 'none' }} />

        <div style={{ padding: '22px 20px 8px', position: 'relative', zIndex: 1 }}>
          <div style={{ fontSize: 13, color: C.textSec, marginBottom: 2 }}>{new Date().toLocaleDateString('ar', { weekday: 'long', month: 'long', day: 'numeric' })}</div>
          <div style={{ fontSize: 27, fontWeight: 800, color: C.text, letterSpacing: -0.8, lineHeight: 1.2 }}>{gr}، تركي 👋</div>
          <div style={{ fontSize: 14, color: C.textSec, marginTop: 4 }}>آيفونك يحتاج انتباهك في ٤ أشياء</div>
        </div>

        {/* Score Card */}
        <div style={{ margin: '14px 16px', position: 'relative', zIndex: 1 }}>
          <Card onClick={() => nav('health')} style={{ padding: 18, background: 'linear-gradient(135deg,rgba(94,92,230,0.25),rgba(10,132,255,0.18))', border: '1px solid rgba(94,92,230,0.28)' }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 14 }}>
              <ScoreRing score={ready ? 74 : 0} size={88} />
              <div style={{ flex: 1 }}>
                <div style={{ fontSize: 11, color: C.textSec, fontWeight: 600, marginBottom: 3, letterSpacing: 0.8, textTransform: 'uppercase' }}>AI Health Score</div>
                <div style={{ fontSize: 20, fontWeight: 800, color: C.text, letterSpacing: -0.4, marginBottom: 8 }}>جيد — يمكن تحسينه</div>
                <div style={{ display: 'flex', gap: 5, flexWrap: 'wrap' }}>
                  <Pill color={C.red}>الخصوصية ⚠️</Pill>
                  <Pill color={C.orange}>التخزين</Pill>
                  <Pill color={C.green}>الأداء ✓</Pill>
                </div>
              </div>
            </div>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: 8, marginTop: 14 }}>
              {[['🔋','البطارية','78%',C.yellow],['💾','التخزين','61%',C.orange],['🔒','الخصوصية','45%',C.red]].map(([icon,label,val,col]) => (
                <div key={label} style={{ background: 'rgba(255,255,255,0.06)', borderRadius: 12, padding: '8px 10px' }}>
                  <div style={{ fontSize: 15, marginBottom: 3 }}>{icon}</div>
                  <div style={{ fontSize: 10, color: C.textSec, marginBottom: 1 }}>{label}</div>
                  <div style={{ fontSize: 13, fontWeight: 700, color: col }}>{val}</div>
                </div>
              ))}
            </div>
          </Card>
        </div>
      </div>

      {/* Quick Actions */}
      <div style={{ padding: '4px 16px 0' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 10 }}>
          <div style={{ fontSize: 17, fontWeight: 700, color: C.text, letterSpacing: -0.3 }}>إجراءات سريعة</div>
        </div>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3,1fr)', gap: 10 }}>
          {[['🧹','تنظيف',C.blue,'storage'],['🔋','البطارية',C.green,'battery'],['🔒','الخصوصية',C.purple,'privacy'],['📸','الصور',C.orange,'photos'],['📅','التقويم',C.teal,'calendar'],['🤖','المساعد',C.indigo,'assistant']].map(([icon,label,col,screen]) => (
            <Card key={label} onClick={() => nav(screen)} style={{ padding: '13px 8px', display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 6 }}>
              <div style={{ width: 40, height: 40, borderRadius: 12, background: col + '22', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 20 }}>{icon}</div>
              <div style={{ fontSize: 11, fontWeight: 600, color: C.text }}>{label}</div>
            </Card>
          ))}
        </div>
      </div>

      {/* Insights */}
      <div style={{ padding: '18px 16px 0' }}>
        <div style={{ fontSize: 17, fontWeight: 700, color: C.text, letterSpacing: -0.3, marginBottom: 10 }}>توصيات AI</div>
        {[['📸','٣٤٧ صورة مكررة تأخذ ٢.١ غيغا',C.orange,'photos'],['🔋','صحة البطارية ٧٨٪ — يُنصح بالاستبدال',C.yellow,'battery'],['🔒','٥ تطبيقات لها صلاحية الموقع دائماً',C.red,'privacy'],['💾','٦.٣ غيغا يمكن تحريرها الآن',C.blue,'storage']].map(([icon,text,col,screen],i) => (
          <Card key={i} onClick={() => nav(screen)} style={{ padding: '12px 14px', marginBottom: 8, display: 'flex', alignItems: 'center', gap: 12 }}>
            <div style={{ width: 36, height: 36, borderRadius: 10, background: col + '1A', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 17, flexShrink: 0 }}>{icon}</div>
            <div style={{ flex: 1, fontSize: 13, color: C.text, lineHeight: 1.4 }}>{text}</div>
            <div style={{ color: C.textTer, fontSize: 16 }}>›</div>
          </Card>
        ))}
      </div>

      {/* Storage */}
      <div style={{ padding: '18px 16px 0' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 10 }}>
          <div style={{ fontSize: 17, fontWeight: 700, color: C.text }}>التخزين</div>
          <button onClick={() => nav('storage')} style={{ background: 'none', border: 'none', color: C.blue, fontSize: 14, fontWeight: 600, cursor: 'pointer' }}>تفاصيل</button>
        </div>
        <Card style={{ padding: 16 }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 10 }}>
            <div><div style={{ fontSize: 24, fontWeight: 800, color: C.text, letterSpacing: -0.5 }}>٨٣.٢ GB</div><div style={{ fontSize: 11, color: C.textSec }}>مستخدم من ٢٥٦ GB</div></div>
            <div style={{ textAlign: 'left' }}><div style={{ fontSize: 22, fontWeight: 800, color: C.green }}>١٧٢.٨</div><div style={{ fontSize: 11, color: C.textSec }}>متاح</div></div>
          </div>
          <div style={{ display: 'flex', height: 8, borderRadius: 99, overflow: 'hidden', gap: 2 }}>
            {[[32,C.orange],[18,C.blue],[12,C.purple],[8,C.pink],[30,'rgba(255,255,255,0.07)']].map(([w,c],i) => (
              <div key={i} style={{ width: w+'%', background: c, borderRadius: 99 }} />
            ))}
          </div>
        </Card>
      </div>

      {/* Subs */}
      <div style={{ padding: '18px 16px 0' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 10 }}>
          <div style={{ fontSize: 17, fontWeight: 700, color: C.text }}>الاشتراكات</div>
          <button onClick={() => nav('subscriptions')} style={{ background: 'none', border: 'none', color: C.blue, fontSize: 14, fontWeight: 600, cursor: 'pointer' }}>إدارة</button>
        </div>
        <Card style={{ padding: 16 }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12 }}>
            <div><div style={{ fontSize: 11, color: C.textSec, marginBottom: 1 }}>إجمالي شهري</div><div style={{ fontSize: 26, fontWeight: 800, color: C.text, letterSpacing: -0.5 }}>١٤١ ر.س</div></div>
            <div style={{ background: C.red + '22', border: '1px solid ' + C.red + '44', borderRadius: 12, padding: '6px 12px', textAlign: 'center' }}>
              <div style={{ fontSize: 18, fontWeight: 800, color: C.red }}>٣</div><div style={{ fontSize: 10, color: C.red }}>منسية</div>
            </div>
          </div>
          {[['🎬','Netflix','٤٩ ر.س',C.red],['☁️','iCloud+','١٩ ر.س',C.blue],['🎵','Spotify','٢٩ ر.س',C.green]].map(([icon,name,price,col]) => (
            <div key={name} style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 8 }}>
              <div style={{ width: 32, height: 32, borderRadius: 8, background: col + '22', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 15 }}>{icon}</div>
              <div style={{ flex: 1, fontSize: 13, fontWeight: 600, color: C.text }}>{name}</div>
              <div style={{ fontSize: 13, color: C.textSec }}>{price}</div>
            </div>
          ))}
        </Card>
      </div>
    </div>
  )
}

// ── HEALTH ──
function HealthScreen() {
  const cats = [
    ['💾','التخزين',61,C.orange],['🔋','البطارية',78,C.yellow],['🔒','الخصوصية',45,C.red],
    ['🛡️','الأمان',88,C.green],['📸','الصور',55,C.purple],['📁','الملفات',72,C.blue],
    ['💳','الاشتراكات',65,C.pink],['📱','التطبيقات',80,C.teal],['👥','جهات الاتصال',69,C.indigo],
    ['📅','التقويم',91,C.green],['☁️','النسخ الاحتياطي',95,C.blue],['⚡','الأداء',84,C.yellow],
  ]
  const overall = Math.round(cats.reduce((a,c) => a + c[2], 0) / cats.length)
  const [ready, setReady] = useState(false)
  useEffect(() => { setTimeout(() => setReady(true), 200) }, [])

  return (
    <div style={{ flex: 1, overflowY: 'auto', paddingBottom: 90 }}>
      <div style={{ padding: '20px 16px 24px', display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 8, position: 'relative', overflow: 'hidden' }}>
        <div style={{ position: 'absolute', width: 300, height: 300, borderRadius: '50%', background: C.indigo, filter: 'blur(90px)', opacity: 0.18, top: -100, left: '50%', transform: 'translateX(-50%)', pointerEvents: 'none' }} />
        <ScoreRing score={ready ? overall : 0} size={140} stroke={12} />
        <div style={{ fontSize: 22, fontWeight: 800, color: C.text, letterSpacing: -0.5 }}>صحة آيفونك</div>
        <div style={{ fontSize: 13, color: C.textSec }}>جيد — يمكن تحسينه بخطوات بسيطة</div>
        <div style={{ display: 'flex', gap: 8 }}><Pill color={C.red}>٣ مشاكل حرجة</Pill><Pill color={C.orange}>٤ تحسينات</Pill></div>
      </div>
      <div style={{ padding: '0 16px' }}>
        {cats.map(([icon,label,score,col]) => (
          <Card key={label} style={{ padding: '12px 14px', marginBottom: 8 }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
              <div style={{ fontSize: 20, width: 32 }}>{icon}</div>
              <div style={{ flex: 1 }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 5 }}>
                  <div style={{ fontSize: 14, fontWeight: 600, color: C.text }}>{label}</div>
                  <div style={{ fontSize: 14, fontWeight: 700, color: col }}>{score}</div>
                </div>
                <ProgressBar value={score} color={col} />
              </div>
            </div>
          </Card>
        ))}
      </div>
    </div>
  )
}

// ── ASSISTANT (Real AI) ──
function AssistantScreen() {
  const [msgs, setMsgs] = useState([
    { role: 'assistant', text: 'مرحباً تركي! 👋 أنا iFlow AI.\n\nيمكنني مساعدتك في:\n• تحليل أداء آيفونك\n• توفير مساحة التخزين\n• مراجعة الخصوصية\n• تنظيم الصور والاشتراكات\n\nكيف يمكنني مساعدتك اليوم؟' }
  ])
  const [input, setInput] = useState('')
  const [loading, setLoading] = useState(false)
  const endRef = useRef(null)

  const QUICK = ['آيفوني بطيء','أريد مساحة أكثر','راجع خصوصيتي','نظّم صوري','ما هو Health Score؟','اشتراكات منسية']

  useEffect(() => { endRef.current?.scrollIntoView({ behavior: 'smooth' }) }, [msgs, loading])

  const send = async (text) => {
    if (!text.trim() || loading) return
    const userMsg = { role: 'user', text }
    const newMsgs = [...msgs, userMsg]
    setMsgs(newMsgs)
    setInput('')
    setLoading(true)

    try {
      const res = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          messages: newMsgs.map(m => ({ role: m.role === 'assistant' ? 'assistant' : 'user', content: m.text })),
          systemPrompt: 'أنت iFlow AI، مساعد ذكي متخصص في مساعدة مستخدمي الآيفون. لديك معرفة عميقة بـ iOS وإدارة التخزين والبطارية والخصوصية والصور والاشتراكات. المستخدم اسمه تركي. أجب بالعربية بشكل ودي ومختصر وعملي مع إيموجي مناسبة.'
        })
      })
      const data = await res.json()
      setMsgs(m => [...m, { role: 'assistant', text: data.text }])
    } catch {
      setMsgs(m => [...m, { role: 'assistant', text: '❌ خطأ في الاتصال، حاول مجدداً.' }])
    }
    setLoading(false)
  }

  return (
    <div style={{ flex: 1, display: 'flex', flexDirection: 'column', overflow: 'hidden' }}>
      <div style={{ flex: 1, overflowY: 'auto', padding: '14px 16px 10px' }}>
        {msgs.map((m, i) => (
          <div key={i} style={{ display: 'flex', justifyContent: m.role === 'user' ? 'flex-start' : 'flex-end', marginBottom: 10 }}>
            <div style={{ maxWidth: '84%', background: m.role === 'user' ? C.surfaceHigh : 'linear-gradient(135deg,rgba(94,92,230,0.28),rgba(10,132,255,0.18))', border: '1px solid ' + (m.role === 'user' ? C.border : 'rgba(94,92,230,0.3)'), borderRadius: m.role === 'user' ? '18px 4px 18px 18px' : '4px 18px 18px 18px', padding: '11px 14px', fontSize: 14, color: C.text, lineHeight: 1.6, whiteSpace: 'pre-wrap' }}>
              {m.text}
            </div>
          </div>
        ))}
        {loading && (
          <div style={{ display: 'flex', justifyContent: 'flex-end', marginBottom: 10 }}>
            <div style={{ background: 'linear-gradient(135deg,rgba(94,92,230,0.28),rgba(10,132,255,0.18))', border: '1px solid rgba(94,92,230,0.3)', borderRadius: '4px 18px 18px 18px', padding: '14px 18px', display: 'flex', gap: 5 }}>
              {[0,1,2].map(j => <div key={j} style={{ width: 7, height: 7, borderRadius: '50%', background: C.indigo, animation: 'pulse 1.2s ' + (j*0.2) + 's infinite' }} />)}
            </div>
          </div>
        )}
        <div ref={endRef} />
      </div>

      <div style={{ padding: '6px 16px 4px', overflowX: 'auto' }}>
        <div style={{ display: 'flex', gap: 7, paddingBottom: 2 }}>
          {QUICK.map((q, i) => (
            <button key={i} onClick={() => send(q)} disabled={loading} style={{ background: C.surfaceHigh, border: '1px solid ' + C.border, color: C.textSec, borderRadius: 99, padding: '6px 12px', fontSize: 12, whiteSpace: 'nowrap', cursor: 'pointer', fontFamily: 'inherit', flexShrink: 0, opacity: loading ? 0.5 : 1 }}>{q}</button>
          ))}
        </div>
      </div>

      <div style={{ padding: '8px 16px 24px', borderTop: '1px solid ' + C.border }}>
        <div style={{ display: 'flex', gap: 8, background: C.surfaceHigh, border: '1px solid ' + C.border, borderRadius: 16, padding: '8px 12px', alignItems: 'center' }}>
          <input value={input} onChange={e => setInput(e.target.value)} onKeyDown={e => { if (e.key === 'Enter' && input.trim()) send(input) }}
            placeholder="اسأل iFlow AI..." style={{ flex: 1, background: 'none', border: 'none', outline: 'none', color: C.text, fontSize: 15, fontFamily: 'inherit', direction: 'rtl' }} />
          <button onClick={() => send(input)} disabled={loading || !input.trim()} style={{ width: 36, height: 36, borderRadius: 10, background: (!loading && input.trim()) ? 'linear-gradient(135deg,#0A84FF,#5E5CE6)' : C.surfaceHigh, border: 'none', color: '#fff', fontSize: 17, cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0, transition: 'all 0.2s' }}>↑</button>
        </div>
      </div>
    </div>
  )
}

// ── STORAGE ──
function StorageScreen() {
  const items = [['📸','الصور والفيديو',32.4,C.orange],['📱','التطبيقات',18.1,C.blue],['🎵','الموسيقى',9.8,C.purple],['💬','الرسائل',7.2,C.teal],['📁','الملفات',6.3,C.yellow],['🔄','النسخ الاحتياطي',5.1,C.green],['⚙️','النظام',4.3,C.textTer]]
  return (
    <div style={{ flex: 1, overflowY: 'auto', paddingBottom: 90, padding: '16px 16px 90px' }}>
      <Card style={{ padding: 18, marginBottom: 14 }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-end', marginBottom: 12 }}>
          <div><div style={{ fontSize: 11, color: C.textSec, marginBottom: 1 }}>مستخدم</div><div style={{ fontSize: 32, fontWeight: 900, color: C.text, letterSpacing: -1 }}>٨٣.٢ GB</div></div>
          <div style={{ textAlign: 'right' }}><div style={{ fontSize: 11, color: C.textSec, marginBottom: 1 }}>من ٢٥٦ GB</div><div style={{ fontSize: 20, fontWeight: 700, color: C.green }}>١٧٢.٨ متاح</div></div>
        </div>
        <div style={{ display: 'flex', height: 10, borderRadius: 99, overflow: 'hidden', gap: 2 }}>
          {items.map(([,, size, col], i) => <div key={i} style={{ width: ((size/83.2)*100)+'%', background: col, borderRadius: 99, minWidth: 3 }} />)}
        </div>
      </Card>
      {items.map(([icon, label, size, col]) => (
        <Card key={label} style={{ padding: '12px 14px', marginBottom: 8 }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
            <div style={{ fontSize: 20, width: 32 }}>{icon}</div>
            <div style={{ flex: 1 }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 5 }}>
                <div style={{ fontSize: 14, fontWeight: 600, color: C.text }}>{label}</div>
                <div style={{ fontSize: 13, color: col, fontWeight: 700 }}>{size} GB</div>
              </div>
              <ProgressBar value={(size/83.2)*100} color={col} />
            </div>
          </div>
        </Card>
      ))}
      <Card style={{ padding: 16, marginTop: 6, background: 'rgba(10,132,255,0.1)', border: '1px solid rgba(10,132,255,0.22)' }}>
        <div style={{ fontSize: 14, fontWeight: 700, color: C.text, marginBottom: 5 }}>⚡ يمكن تحرير ٦.٣ GB الآن</div>
        <div style={{ fontSize: 13, color: C.textSec, marginBottom: 12 }}>٣٤٧ صورة مكررة + ٨٩ فيديو قديم + ٢٣٤ لقطة شاشة</div>
        <button style={{ width: '100%', background: 'linear-gradient(135deg,#0A84FF,#5E5CE6)', border: 'none', borderRadius: 13, color: '#fff', fontSize: 14, fontWeight: 700, padding: '11px 0', cursor: 'pointer' }}>تنظيف ذكي ✨</button>
      </Card>
    </div>
  )
}

// ── BATTERY ──
function BatteryScreen() {
  const [ready, setReady] = useState(false)
  useEffect(() => { setTimeout(() => setReady(true), 200) }, [])
  return (
    <div style={{ flex: 1, overflowY: 'auto', paddingBottom: 90, padding: '16px 16px 90px' }}>
      <Card style={{ padding: 18, background: 'linear-gradient(135deg,rgba(48,209,88,0.12),rgba(64,203,224,0.08))', border: '1px solid rgba(48,209,88,0.18)', marginBottom: 14 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 14 }}>
          <ScoreRing score={ready ? 78 : 0} size={88} />
          <div>
            <div style={{ fontSize: 12, color: C.textSec, marginBottom: 3 }}>صحة البطارية</div>
            <div style={{ fontSize: 28, fontWeight: 900, color: C.yellow, letterSpacing: -0.5 }}>٧٨٪</div>
            <div style={{ fontSize: 13, color: C.textSec }}>يُنصح بالاستبدال قريباً</div>
          </div>
        </div>
      </Card>
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10, marginBottom: 14 }}>
        {[['⚡','الشحن الحالي','٩٤٪',C.green],['🌡️','الحرارة','عادية',C.blue],['🔄','دورات الشحن','٥٦٧',C.orange],['⏱️','وقت الاستخدام','٦ ساعات',C.purple]].map(([icon,label,val,col]) => (
          <Card key={label} style={{ padding: 14 }}>
            <div style={{ fontSize: 22, marginBottom: 6 }}>{icon}</div>
            <div style={{ fontSize: 11, color: C.textSec, marginBottom: 2 }}>{label}</div>
            <div style={{ fontSize: 17, fontWeight: 800, color: col }}>{val}</div>
          </Card>
        ))}
      </div>
      {[['🌙','فعّل وضع الطاقة المنخفضة ليلاً','عالي'],['📶','أوقف تحديث التطبيقات في الخلفية','متوسط'],['🔆','اخفض السطوع إلى ٧٠٪','متوسط'],['📍','قلّل صلاحيات الموقع الدائم','عالي']].map(([icon, text, impact], i) => (
        <Card key={i} style={{ padding: '12px 14px', marginBottom: 8, display: 'flex', alignItems: 'center', gap: 12 }}>
          <div style={{ fontSize: 20 }}>{icon}</div>
          <div style={{ flex: 1, fontSize: 13, color: C.text }}>{text}</div>
          <Pill color={impact === 'عالي' ? C.green : C.orange}>{impact}</Pill>
        </Card>
      ))}
    </div>
  )
}

// ── PRIVACY ──
function PrivacyScreen() {
  const [ready, setReady] = useState(false)
  useEffect(() => { setTimeout(() => setReady(true), 200) }, [])
  return (
    <div style={{ flex: 1, overflowY: 'auto', paddingBottom: 90, padding: '16px 16px 90px' }}>
      <Card style={{ padding: 18, background: 'linear-gradient(135deg,rgba(255,69,58,0.12),rgba(191,90,242,0.08))', border: '1px solid rgba(255,69,58,0.2)', marginBottom: 14 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 14 }}>
          <ScoreRing score={ready ? 45 : 0} size={88} />
          <div>
            <div style={{ fontSize: 12, color: C.textSec, marginBottom: 3 }}>درجة الخصوصية</div>
            <div style={{ fontSize: 22, fontWeight: 800, color: C.red }}>تحتاج مراجعة</div>
            <div style={{ fontSize: 13, color: C.textSec }}>٥ تطبيقات لها صلاحيات خطرة</div>
          </div>
        </div>
      </Card>
      {[['📍','الموقع دائماً',5,'عالي',C.red],['🎙️','الميكروفون',8,'متوسط',C.orange],['📷','الكاميرا',11,'منخفض',C.yellow],['📸','الصور كاملة',14,'متوسط',C.orange],['📬','الإشعارات',32,'منخفض',C.blue],['🔵','البلوتوث',6,'متوسط',C.orange]].map(([icon,label,apps,risk,col],i) => (
        <Card key={i} style={{ padding: '13px 14px', marginBottom: 8 }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
            <div style={{ fontSize: 20, width: 32 }}>{icon}</div>
            <div style={{ flex: 1 }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 3 }}>
                <div style={{ fontSize: 14, fontWeight: 600, color: C.text }}>{label}</div>
                <Pill color={col}>{risk}</Pill>
              </div>
              <div style={{ fontSize: 12, color: C.textSec }}>{apps} تطبيق</div>
            </div>
          </div>
        </Card>
      ))}
    </div>
  )
}

// ── PHOTOS ──
function PhotosScreen() {
  return (
    <div style={{ flex: 1, overflowY: 'auto', paddingBottom: 90, padding: '16px 16px 90px' }}>
      <Card style={{ padding: 18, background: 'linear-gradient(135deg,rgba(191,90,242,0.18),rgba(255,55,95,0.12))', border: '1px solid rgba(191,90,242,0.22)', marginBottom: 14 }}>
        <div style={{ fontSize: 12, color: C.textSec, marginBottom: 1 }}>يمكن توفير</div>
        <div style={{ fontSize: 36, fontWeight: 900, color: C.text, letterSpacing: -1, marginBottom: 3 }}>٨.٥ GB</div>
        <div style={{ fontSize: 13, color: C.textSec, marginBottom: 14 }}>من ١٬١٠٤ صور وفيديوهات غير ضرورية</div>
        <button style={{ width: '100%', background: 'linear-gradient(135deg,#BF5AF2,#FF375F)', border: 'none', borderRadius: 13, color: '#fff', fontSize: 15, fontWeight: 700, padding: '12px 0', cursor: 'pointer' }}>تنظيف ذكي بالـ AI ✨</button>
      </Card>
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10 }}>
        {[['👥','مكررة',347,'٢.١ GB',C.red,true],['🌫️','ضبابية',89,'٤٢٠ MB',C.orange,false],['📱','لقطات شاشة',234,'١.٢ GB',C.blue,false],['🎬','فيديوهات كبيرة',12,'٣.٨ GB',C.purple,true],['🧾','إيصالات',56,'٢٨٠ MB',C.yellow,false],['😂','ميمز',145,'٦٨٠ MB',C.pink,false]].map(([icon,label,count,size,col,urgent],i) => (
          <Card key={i} style={{ padding: '13px 12px' }}>
            {urgent && <div style={{ background: C.red, borderRadius: 5, fontSize: 9, fontWeight: 800, color: '#fff', padding: '1px 6px', marginBottom: 5, display: 'inline-block' }}>مهم</div>}
            <div style={{ fontSize: 24, marginBottom: 4 }}>{icon}</div>
            <div style={{ fontSize: 13, fontWeight: 700, color: C.text, marginBottom: 2 }}>{label}</div>
            <div style={{ fontSize: 11, color: C.textSec, marginBottom: 8 }}>{count} · {size}</div>
            <button style={{ width: '100%', background: col + '22', border: '1px solid ' + col + '44', color: col, fontSize: 11, fontWeight: 700, padding: '5px 0', borderRadius: 8, cursor: 'pointer' }}>مراجعة</button>
          </Card>
        ))}
      </div>
    </div>
  )
}

// ── CALENDAR ──
function CalendarScreen() {
  return (
    <div style={{ flex: 1, overflowY: 'auto', paddingBottom: 90, padding: '16px 16px 90px' }}>
      <Card style={{ padding: 14, background: 'rgba(255,69,58,0.1)', border: '1px solid rgba(255,69,58,0.22)', marginBottom: 14 }}>
        <div style={{ fontSize: 14, fontWeight: 700, color: C.red, marginBottom: 4 }}>⚠️ تعارض في المواعيد</div>
        <div style={{ fontSize: 13, color: C.textSec, marginBottom: 10 }}>اجتماع ١٠:٣٠ والعرض ١١:٠٠ يتداخلان</div>
        <button style={{ background: C.red, border: 'none', borderRadius: 10, color: '#fff', fontSize: 13, fontWeight: 700, padding: '8px 16px', cursor: 'pointer' }}>حل التعارض</button>
      </Card>
      {[['٩:٠٠ ص','اجتماع الفريق',false,C.blue],['١٠:٣٠ ص','مكالمة مع العميل',true,C.red],['١١:٠٠ ص','عرض تقديمي',true,C.red],['٢:٠٠ م','وقت التركيز',false,C.green],['٤:٣٠ م','مراجعة المشروع',false,C.purple]].map(([time,title,conflict,col],i) => (
        <Card key={i} style={{ padding: '13px 14px', marginBottom: 8, borderRight: '3px solid ' + col }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
            <div style={{ fontSize: 12, color: col, fontWeight: 700, width: 52, flexShrink: 0 }}>{time}</div>
            <div style={{ flex: 1, fontSize: 14, fontWeight: 600, color: C.text }}>{title}</div>
            {conflict && <Pill color={C.red}>تعارض</Pill>}
          </div>
        </Card>
      ))}
    </div>
  )
}

// ── SUBSCRIPTIONS ──
function SubscriptionsScreen() {
  const subs = [['🎬','Netflix',49,C.red,false],['☁️','iCloud+',19,C.blue,false],['🎵','Spotify',29,C.green,false],['📺','Apple TV+',25,C.textSec,true],['🎮','Apple Arcade',19,C.purple,true],['📰','مجلة رقمية',15,C.yellow,true]]
  const total = subs.reduce((a,s) => a + s[2], 0)
  return (
    <div style={{ flex: 1, overflowY: 'auto', paddingBottom: 90, padding: '16px 16px 90px' }}>
      <Card style={{ padding: 18, background: 'linear-gradient(135deg,rgba(255,55,95,0.12),rgba(255,159,10,0.08))', border: '1px solid rgba(255,55,95,0.18)', marginBottom: 14 }}>
        <div style={{ fontSize: 11, color: C.textSec, marginBottom: 1 }}>إجمالي شهري</div>
        <div style={{ fontSize: 34, fontWeight: 900, color: C.text, letterSpacing: -1, marginBottom: 2 }}>{total} ر.س</div>
        <div style={{ fontSize: 13, color: C.textSec, marginBottom: 10 }}>{total * 12} ر.س سنوياً</div>
        <div style={{ display: 'flex', gap: 8 }}>
          <Pill color={C.red}>٣ منسية</Pill>
          <Pill color={C.orange}>وفّر ٥٩ ر.س/شهر</Pill>
        </div>
      </Card>
      <div style={{ fontSize: 13, color: C.red, fontWeight: 700, marginBottom: 8 }}>🔴 منسية — يُنصح بالإلغاء</div>
      {subs.filter(s => s[4]).map(([icon,name,price,col],i) => (
        <Card key={i} style={{ padding: '13px 14px', marginBottom: 8, border: '1px solid rgba(255,69,58,0.22)' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
            <div style={{ width: 36, height: 36, borderRadius: 10, background: col + '22', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 17 }}>{icon}</div>
            <div style={{ flex: 1 }}><div style={{ fontSize: 14, fontWeight: 700, color: C.text }}>{name}</div><div style={{ fontSize: 12, color: C.textSec }}>{price} ر.س/شهر</div></div>
            <button style={{ background: C.red + '22', border: '1px solid ' + C.red + '44', color: C.red, fontSize: 11, fontWeight: 700, padding: '5px 10px', borderRadius: 8, cursor: 'pointer' }}>إلغاء</button>
          </div>
        </Card>
      ))}
      <div style={{ fontSize: 13, color: C.textSec, fontWeight: 600, marginTop: 8, marginBottom: 8 }}>اشتراكاتك النشطة</div>
      {subs.filter(s => !s[4]).map(([icon,name,price,col],i) => (
        <Card key={i} style={{ padding: '13px 14px', marginBottom: 8 }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
            <div style={{ width: 36, height: 36, borderRadius: 10, background: col + '22', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 17 }}>{icon}</div>
            <div style={{ flex: 1 }}><div style={{ fontSize: 14, fontWeight: 600, color: C.text }}>{name}</div></div>
            <div style={{ fontSize: 14, fontWeight: 700, color: col }}>{price} ر.س</div>
          </div>
        </Card>
      ))}
    </div>
  )
}

// ── NAV ──
const NAV = [['home','⊞','الرئيسية'],['health','❤️','الصحة'],['photos','📸','الصور'],['storage','💾','التخزين'],['assistant','🤖','AI']]
const TITLES = { home:'iFlow AI', health:'Health Score', photos:'استوديو الصور', storage:'التخزين', battery:'البطارية', privacy:'الخصوصية', calendar:'التقويم', subscriptions:'الاشتراكات', assistant:'iFlow AI' }
const SCREENS = { home:HomeScreen, health:HealthScreen, photos:PhotosScreen, storage:StorageScreen, battery:BatteryScreen, privacy:PrivacyScreen, calendar:CalendarScreen, subscriptions:SubscriptionsScreen, assistant:AssistantScreen }

export default function App() {
  const [screen, setScreen] = useState('home')
  const [prev, setPrev] = useState(null)
  const nav = s => { setPrev(screen); setScreen(s) }
  const back = () => setScreen(prev || 'home')
  const Active = SCREENS[screen] || HomeScreen
  const inNav = NAV.find(n => n[0] === screen)

  return (
    <div style={{ maxWidth: 430, margin: '0 auto', height: '100vh', background: C.bg, display: 'flex', flexDirection: 'column', fontFamily: "-apple-system,'SF Pro Display','Helvetica Neue',sans-serif", direction: 'rtl', overflow: 'hidden' }}>
      {/* Header */}
      <div style={{ background: 'rgba(0,0,0,0.88)', backdropFilter: 'blur(20px)', WebkitBackdropFilter: 'blur(20px)', borderBottom: '1px solid ' + C.border, padding: '12px 16px 10px', flexShrink: 0, zIndex: 10 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
          {!inNav && prev && (
            <button onClick={back} style={{ background: 'none', border: 'none', color: C.blue, fontSize: 15, cursor: 'pointer', padding: 0, fontFamily: 'inherit', display: 'flex', alignItems: 'center', gap: 2 }}>
              <span style={{ fontSize: 20 }}>‹</span> رجوع
            </button>
          )}
          <div style={{ flex: 1, textAlign: 'center', fontSize: 17, fontWeight: 700, color: C.text, letterSpacing: -0.3 }}>
            {screen === 'home'
              ? <span style={{ background: 'linear-gradient(135deg,#0A84FF,#BF5AF2)', WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent', fontWeight: 900, fontSize: 20 }}>iFlow AI</span>
              : TITLES[screen]}
          </div>
          <div style={{ width: 60, display: 'flex', justifyContent: 'flex-end' }}>
            {screen === 'home' && <div style={{ width: 34, height: 34, borderRadius: 10, background: 'linear-gradient(135deg,#0A84FF,#5E5CE6)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 16 }}>⚡</div>}
          </div>
        </div>
      </div>

      {/* Screen */}
      <div style={{ flex: 1, display: 'flex', flexDirection: 'column', overflow: 'hidden' }}>
        <Active nav={nav} />
      </div>

      {/* Tab Bar */}
      <div style={{ background: 'rgba(0,0,0,0.92)', backdropFilter: 'blur(30px)', WebkitBackdropFilter: 'blur(30px)', borderTop: '1px solid ' + C.border, padding: '8px 0 20px', flexShrink: 0, zIndex: 10 }}>
        <div style={{ display: 'flex', justifyContent: 'space-around' }}>
          {NAV.map(([id, icon, label]) => {
            const active = screen === id
            return (
              <button key={id} onClick={() => nav(id)} style={{ background: 'none', border: 'none', cursor: 'pointer', display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 2, padding: '4px 10px', fontFamily: 'inherit' }}>
                <div style={{ fontSize: 22, opacity: active ? 1 : 0.45, transform: active ? 'scale(1.15)' : 'scale(1)', transition: 'all 0.2s cubic-bezier(.34,1.56,.64,1)' }}>{icon}</div>
                <div style={{ fontSize: 10, fontWeight: active ? 700 : 400, color: active ? C.blue : C.textTer, transition: 'color 0.2s' }}>{label}</div>
                {active && <div style={{ width: 4, height: 4, borderRadius: '50%', background: C.blue, marginTop: 1 }} />}
              </button>
            )
          })}
        </div>
      </div>

      <style>{`
        * { box-sizing: border-box; -webkit-tap-highlight-color: transparent; }
        body { margin: 0; background: #000; }
        ::-webkit-scrollbar { display: none; }
        input::placeholder { color: rgba(255,255,255,0.22); }
        @keyframes pulse { 0%,80%,100%{transform:scale(1);opacity:0.4} 40%{transform:scale(1.4);opacity:1} }
      `}</style>
    </div>
  )
}
