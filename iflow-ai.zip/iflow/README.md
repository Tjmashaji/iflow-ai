# iFlow AI — PWA

## النشر على Vercel

1. ارفع هذا المجلد على GitHub
2. افتح vercel.com وربطه
3. أضف Environment Variable:
   - ANTHROPIC_API_KEY = مفتاحك من console.anthropic.com
4. انشر!

## إضافة للـ Home Screen

1. افتح الرابط في Safari
2. اضغط Share ثم "Add to Home Screen"
3. يشتغل مثل تطبيق حقيقي!
